package edu.uned.iss.tfm.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.common.util.Enumerator;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import edu.uned.iss.tfm.services.AatDSLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalAatDSLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_STRING", "RULE_INT", "RULE_COMMENT", "RULE_ID", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'Feature:'", "'Scenario:'", "'Given:'", "'When:'", "'Then:'", "'Activity_to_check'", "'I'", "'type'", "'input'", "'into'", "'tap'", "'press'", "'click'", "'over'", "'choose'", "'select'", "'in'", "'And'", "'But'", "'is'", "'enabled'", "'visible'", "'Option'", "'checked'", "'Value'", "'selected'", "'at'", "'Message'", "'showed'", "'Content'", "'.'", "'\\u00E1'", "'\\u00E9'", "'\\u00ED'", "'\\u00F3'", "'\\u00FA'", "'\\u00F1'", "'\\\\'", "'startsWith'", "'endsWith'", "'contains'", "'equals'", "'greaterThan'", "'greaterEqualsThan'", "'lessThan'", "'lessEqualsThan'"
    };
    public static final int T__50=50;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__55=55;
    public static final int T__12=12;
    public static final int T__56=56;
    public static final int T__13=13;
    public static final int T__57=57;
    public static final int T__14=14;
    public static final int T__51=51;
    public static final int T__52=52;
    public static final int T__53=53;
    public static final int T__54=54;
    public static final int RULE_ID=7;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=5;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;
    public static final int RULE_STRING=4;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__37=37;
    public static final int T__38=38;
    public static final int T__39=39;
    public static final int T__33=33;
    public static final int T__34=34;
    public static final int T__35=35;
    public static final int T__36=36;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_WS=10;
    public static final int RULE_COMMENT=6;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__48=48;
    public static final int T__49=49;
    public static final int T__44=44;
    public static final int T__45=45;
    public static final int T__46=46;
    public static final int T__47=47;
    public static final int T__40=40;
    public static final int T__41=41;
    public static final int T__42=42;
    public static final int T__43=43;

    // delegates
    // delegators


        public InternalAatDSLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalAatDSLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalAatDSLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalAatDSL.g"; }



     	private AatDSLGrammarAccess grammarAccess;

        public InternalAatDSLParser(TokenStream input, AatDSLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected AatDSLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalAatDSL.g:65:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalAatDSL.g:65:46: (iv_ruleModel= ruleModel EOF )
            // InternalAatDSL.g:66:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalAatDSL.g:72:1: ruleModel returns [EObject current=null] : ( (lv_feature_0_0= ruleFeature ) ) ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_feature_0_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:78:2: ( ( (lv_feature_0_0= ruleFeature ) ) )
            // InternalAatDSL.g:79:2: ( (lv_feature_0_0= ruleFeature ) )
            {
            // InternalAatDSL.g:79:2: ( (lv_feature_0_0= ruleFeature ) )
            // InternalAatDSL.g:80:3: (lv_feature_0_0= ruleFeature )
            {
            // InternalAatDSL.g:80:3: (lv_feature_0_0= ruleFeature )
            // InternalAatDSL.g:81:4: lv_feature_0_0= ruleFeature
            {

            				newCompositeNode(grammarAccess.getModelAccess().getFeatureFeatureParserRuleCall_0());
            			
            pushFollow(FOLLOW_2);
            lv_feature_0_0=ruleFeature();

            state._fsp--;


            				if (current==null) {
            					current = createModelElementForParent(grammarAccess.getModelRule());
            				}
            				add(
            					current,
            					"feature",
            					lv_feature_0_0,
            					"edu.uned.iss.tfm.AatDSL.Feature");
            				afterParserOrEnumRuleCall();
            			

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleFeature"
    // InternalAatDSL.g:101:1: entryRuleFeature returns [EObject current=null] : iv_ruleFeature= ruleFeature EOF ;
    public final EObject entryRuleFeature() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleFeature = null;


        try {
            // InternalAatDSL.g:101:48: (iv_ruleFeature= ruleFeature EOF )
            // InternalAatDSL.g:102:2: iv_ruleFeature= ruleFeature EOF
            {
             newCompositeNode(grammarAccess.getFeatureRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleFeature=ruleFeature();

            state._fsp--;

             current =iv_ruleFeature; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleFeature"


    // $ANTLR start "ruleFeature"
    // InternalAatDSL.g:108:1: ruleFeature returns [EObject current=null] : (otherlv_0= 'Feature:' ( (lv_description_1_0= RULE_STRING ) ) ( (lv_scenarios_2_0= ruleScenario ) )* ) ;
    public final EObject ruleFeature() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_description_1_0=null;
        EObject lv_scenarios_2_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:114:2: ( (otherlv_0= 'Feature:' ( (lv_description_1_0= RULE_STRING ) ) ( (lv_scenarios_2_0= ruleScenario ) )* ) )
            // InternalAatDSL.g:115:2: (otherlv_0= 'Feature:' ( (lv_description_1_0= RULE_STRING ) ) ( (lv_scenarios_2_0= ruleScenario ) )* )
            {
            // InternalAatDSL.g:115:2: (otherlv_0= 'Feature:' ( (lv_description_1_0= RULE_STRING ) ) ( (lv_scenarios_2_0= ruleScenario ) )* )
            // InternalAatDSL.g:116:3: otherlv_0= 'Feature:' ( (lv_description_1_0= RULE_STRING ) ) ( (lv_scenarios_2_0= ruleScenario ) )*
            {
            otherlv_0=(Token)match(input,12,FOLLOW_3); 

            			newLeafNode(otherlv_0, grammarAccess.getFeatureAccess().getFeatureKeyword_0());
            		
            // InternalAatDSL.g:120:3: ( (lv_description_1_0= RULE_STRING ) )
            // InternalAatDSL.g:121:4: (lv_description_1_0= RULE_STRING )
            {
            // InternalAatDSL.g:121:4: (lv_description_1_0= RULE_STRING )
            // InternalAatDSL.g:122:5: lv_description_1_0= RULE_STRING
            {
            lv_description_1_0=(Token)match(input,RULE_STRING,FOLLOW_4); 

            					newLeafNode(lv_description_1_0, grammarAccess.getFeatureAccess().getDescriptionSTRINGTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getFeatureRule());
            					}
            					setWithLastConsumed(
            						current,
            						"description",
            						lv_description_1_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalAatDSL.g:138:3: ( (lv_scenarios_2_0= ruleScenario ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0==13) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalAatDSL.g:139:4: (lv_scenarios_2_0= ruleScenario )
            	    {
            	    // InternalAatDSL.g:139:4: (lv_scenarios_2_0= ruleScenario )
            	    // InternalAatDSL.g:140:5: lv_scenarios_2_0= ruleScenario
            	    {

            	    					newCompositeNode(grammarAccess.getFeatureAccess().getScenariosScenarioParserRuleCall_2_0());
            	    				
            	    pushFollow(FOLLOW_4);
            	    lv_scenarios_2_0=ruleScenario();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getFeatureRule());
            	    					}
            	    					add(
            	    						current,
            	    						"scenarios",
            	    						lv_scenarios_2_0,
            	    						"edu.uned.iss.tfm.AatDSL.Scenario");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleFeature"


    // $ANTLR start "entryRuleScenario"
    // InternalAatDSL.g:161:1: entryRuleScenario returns [EObject current=null] : iv_ruleScenario= ruleScenario EOF ;
    public final EObject entryRuleScenario() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleScenario = null;


        try {
            // InternalAatDSL.g:161:49: (iv_ruleScenario= ruleScenario EOF )
            // InternalAatDSL.g:162:2: iv_ruleScenario= ruleScenario EOF
            {
             newCompositeNode(grammarAccess.getScenarioRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleScenario=ruleScenario();

            state._fsp--;

             current =iv_ruleScenario; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleScenario"


    // $ANTLR start "ruleScenario"
    // InternalAatDSL.g:168:1: ruleScenario returns [EObject current=null] : (otherlv_0= 'Scenario:' ( (lv_sequence_1_0= RULE_INT ) ) ( (lv_scenario_2_0= RULE_STRING ) ) (otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) ) )? otherlv_5= 'When:' ( (lv_when_6_0= ruleActionsStatements ) ) otherlv_7= 'Then:' ( (lv_then_8_0= ruleThenStatements ) ) ) ;
    public final EObject ruleScenario() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token lv_sequence_1_0=null;
        Token lv_scenario_2_0=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        EObject lv_given_4_0 = null;

        EObject lv_when_6_0 = null;

        EObject lv_then_8_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:174:2: ( (otherlv_0= 'Scenario:' ( (lv_sequence_1_0= RULE_INT ) ) ( (lv_scenario_2_0= RULE_STRING ) ) (otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) ) )? otherlv_5= 'When:' ( (lv_when_6_0= ruleActionsStatements ) ) otherlv_7= 'Then:' ( (lv_then_8_0= ruleThenStatements ) ) ) )
            // InternalAatDSL.g:175:2: (otherlv_0= 'Scenario:' ( (lv_sequence_1_0= RULE_INT ) ) ( (lv_scenario_2_0= RULE_STRING ) ) (otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) ) )? otherlv_5= 'When:' ( (lv_when_6_0= ruleActionsStatements ) ) otherlv_7= 'Then:' ( (lv_then_8_0= ruleThenStatements ) ) )
            {
            // InternalAatDSL.g:175:2: (otherlv_0= 'Scenario:' ( (lv_sequence_1_0= RULE_INT ) ) ( (lv_scenario_2_0= RULE_STRING ) ) (otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) ) )? otherlv_5= 'When:' ( (lv_when_6_0= ruleActionsStatements ) ) otherlv_7= 'Then:' ( (lv_then_8_0= ruleThenStatements ) ) )
            // InternalAatDSL.g:176:3: otherlv_0= 'Scenario:' ( (lv_sequence_1_0= RULE_INT ) ) ( (lv_scenario_2_0= RULE_STRING ) ) (otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) ) )? otherlv_5= 'When:' ( (lv_when_6_0= ruleActionsStatements ) ) otherlv_7= 'Then:' ( (lv_then_8_0= ruleThenStatements ) )
            {
            otherlv_0=(Token)match(input,13,FOLLOW_5); 

            			newLeafNode(otherlv_0, grammarAccess.getScenarioAccess().getScenarioKeyword_0());
            		
            // InternalAatDSL.g:180:3: ( (lv_sequence_1_0= RULE_INT ) )
            // InternalAatDSL.g:181:4: (lv_sequence_1_0= RULE_INT )
            {
            // InternalAatDSL.g:181:4: (lv_sequence_1_0= RULE_INT )
            // InternalAatDSL.g:182:5: lv_sequence_1_0= RULE_INT
            {
            lv_sequence_1_0=(Token)match(input,RULE_INT,FOLLOW_3); 

            					newLeafNode(lv_sequence_1_0, grammarAccess.getScenarioAccess().getSequenceINTTerminalRuleCall_1_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getScenarioRule());
            					}
            					setWithLastConsumed(
            						current,
            						"sequence",
            						lv_sequence_1_0,
            						"org.eclipse.xtext.common.Terminals.INT");
            				

            }


            }

            // InternalAatDSL.g:198:3: ( (lv_scenario_2_0= RULE_STRING ) )
            // InternalAatDSL.g:199:4: (lv_scenario_2_0= RULE_STRING )
            {
            // InternalAatDSL.g:199:4: (lv_scenario_2_0= RULE_STRING )
            // InternalAatDSL.g:200:5: lv_scenario_2_0= RULE_STRING
            {
            lv_scenario_2_0=(Token)match(input,RULE_STRING,FOLLOW_6); 

            					newLeafNode(lv_scenario_2_0, grammarAccess.getScenarioAccess().getScenarioSTRINGTerminalRuleCall_2_0());
            				

            					if (current==null) {
            						current = createModelElement(grammarAccess.getScenarioRule());
            					}
            					setWithLastConsumed(
            						current,
            						"scenario",
            						lv_scenario_2_0,
            						"org.eclipse.xtext.common.Terminals.STRING");
            				

            }


            }

            // InternalAatDSL.g:216:3: (otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) ) )?
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==14) ) {
                alt2=1;
            }
            switch (alt2) {
                case 1 :
                    // InternalAatDSL.g:217:4: otherlv_3= 'Given:' ( (lv_given_4_0= ruleGivenStatements ) )
                    {
                    otherlv_3=(Token)match(input,14,FOLLOW_7); 

                    				newLeafNode(otherlv_3, grammarAccess.getScenarioAccess().getGivenKeyword_3_0());
                    			
                    // InternalAatDSL.g:221:4: ( (lv_given_4_0= ruleGivenStatements ) )
                    // InternalAatDSL.g:222:5: (lv_given_4_0= ruleGivenStatements )
                    {
                    // InternalAatDSL.g:222:5: (lv_given_4_0= ruleGivenStatements )
                    // InternalAatDSL.g:223:6: lv_given_4_0= ruleGivenStatements
                    {

                    						newCompositeNode(grammarAccess.getScenarioAccess().getGivenGivenStatementsParserRuleCall_3_1_0());
                    					
                    pushFollow(FOLLOW_8);
                    lv_given_4_0=ruleGivenStatements();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getScenarioRule());
                    						}
                    						set(
                    							current,
                    							"given",
                    							lv_given_4_0,
                    							"edu.uned.iss.tfm.AatDSL.GivenStatements");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }

            otherlv_5=(Token)match(input,15,FOLLOW_9); 

            			newLeafNode(otherlv_5, grammarAccess.getScenarioAccess().getWhenKeyword_4());
            		
            // InternalAatDSL.g:245:3: ( (lv_when_6_0= ruleActionsStatements ) )
            // InternalAatDSL.g:246:4: (lv_when_6_0= ruleActionsStatements )
            {
            // InternalAatDSL.g:246:4: (lv_when_6_0= ruleActionsStatements )
            // InternalAatDSL.g:247:5: lv_when_6_0= ruleActionsStatements
            {

            					newCompositeNode(grammarAccess.getScenarioAccess().getWhenActionsStatementsParserRuleCall_5_0());
            				
            pushFollow(FOLLOW_10);
            lv_when_6_0=ruleActionsStatements();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getScenarioRule());
            					}
            					set(
            						current,
            						"when",
            						lv_when_6_0,
            						"edu.uned.iss.tfm.AatDSL.ActionsStatements");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_7=(Token)match(input,16,FOLLOW_7); 

            			newLeafNode(otherlv_7, grammarAccess.getScenarioAccess().getThenKeyword_6());
            		
            // InternalAatDSL.g:268:3: ( (lv_then_8_0= ruleThenStatements ) )
            // InternalAatDSL.g:269:4: (lv_then_8_0= ruleThenStatements )
            {
            // InternalAatDSL.g:269:4: (lv_then_8_0= ruleThenStatements )
            // InternalAatDSL.g:270:5: lv_then_8_0= ruleThenStatements
            {

            					newCompositeNode(grammarAccess.getScenarioAccess().getThenThenStatementsParserRuleCall_7_0());
            				
            pushFollow(FOLLOW_2);
            lv_then_8_0=ruleThenStatements();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getScenarioRule());
            					}
            					set(
            						current,
            						"then",
            						lv_then_8_0,
            						"edu.uned.iss.tfm.AatDSL.ThenStatements");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleScenario"


    // $ANTLR start "entryRuleActivityStarted"
    // InternalAatDSL.g:291:1: entryRuleActivityStarted returns [EObject current=null] : iv_ruleActivityStarted= ruleActivityStarted EOF ;
    public final EObject entryRuleActivityStarted() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActivityStarted = null;


        try {
            // InternalAatDSL.g:291:56: (iv_ruleActivityStarted= ruleActivityStarted EOF )
            // InternalAatDSL.g:292:2: iv_ruleActivityStarted= ruleActivityStarted EOF
            {
             newCompositeNode(grammarAccess.getActivityStartedRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActivityStarted=ruleActivityStarted();

            state._fsp--;

             current =iv_ruleActivityStarted; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActivityStarted"


    // $ANTLR start "ruleActivityStarted"
    // InternalAatDSL.g:298:1: ruleActivityStarted returns [EObject current=null] : (otherlv_0= 'Activity_to_check' ( (lv_name_1_0= ruleANDROID_ID ) ) ) ;
    public final EObject ruleActivityStarted() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:304:2: ( (otherlv_0= 'Activity_to_check' ( (lv_name_1_0= ruleANDROID_ID ) ) ) )
            // InternalAatDSL.g:305:2: (otherlv_0= 'Activity_to_check' ( (lv_name_1_0= ruleANDROID_ID ) ) )
            {
            // InternalAatDSL.g:305:2: (otherlv_0= 'Activity_to_check' ( (lv_name_1_0= ruleANDROID_ID ) ) )
            // InternalAatDSL.g:306:3: otherlv_0= 'Activity_to_check' ( (lv_name_1_0= ruleANDROID_ID ) )
            {
            otherlv_0=(Token)match(input,17,FOLLOW_11); 

            			newLeafNode(otherlv_0, grammarAccess.getActivityStartedAccess().getActivity_to_checkKeyword_0());
            		
            // InternalAatDSL.g:310:3: ( (lv_name_1_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:311:4: (lv_name_1_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:311:4: (lv_name_1_0= ruleANDROID_ID )
            // InternalAatDSL.g:312:5: lv_name_1_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getActivityStartedAccess().getNameANDROID_IDParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_1_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getActivityStartedRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActivityStarted"


    // $ANTLR start "entryRuleGivenStatements"
    // InternalAatDSL.g:333:1: entryRuleGivenStatements returns [EObject current=null] : iv_ruleGivenStatements= ruleGivenStatements EOF ;
    public final EObject entryRuleGivenStatements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleGivenStatements = null;


        try {
            // InternalAatDSL.g:333:56: (iv_ruleGivenStatements= ruleGivenStatements EOF )
            // InternalAatDSL.g:334:2: iv_ruleGivenStatements= ruleGivenStatements EOF
            {
             newCompositeNode(grammarAccess.getGivenStatementsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleGivenStatements=ruleGivenStatements();

            state._fsp--;

             current =iv_ruleGivenStatements; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleGivenStatements"


    // $ANTLR start "ruleGivenStatements"
    // InternalAatDSL.g:340:1: ruleGivenStatements returns [EObject current=null] : ( ( (lv_activity_0_0= ruleActivityStarted ) )? ( (lv_validations_1_0= ruleConditionalStatement ) )+ ) ;
    public final EObject ruleGivenStatements() throws RecognitionException {
        EObject current = null;

        EObject lv_activity_0_0 = null;

        EObject lv_validations_1_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:346:2: ( ( ( (lv_activity_0_0= ruleActivityStarted ) )? ( (lv_validations_1_0= ruleConditionalStatement ) )+ ) )
            // InternalAatDSL.g:347:2: ( ( (lv_activity_0_0= ruleActivityStarted ) )? ( (lv_validations_1_0= ruleConditionalStatement ) )+ )
            {
            // InternalAatDSL.g:347:2: ( ( (lv_activity_0_0= ruleActivityStarted ) )? ( (lv_validations_1_0= ruleConditionalStatement ) )+ )
            // InternalAatDSL.g:348:3: ( (lv_activity_0_0= ruleActivityStarted ) )? ( (lv_validations_1_0= ruleConditionalStatement ) )+
            {
            // InternalAatDSL.g:348:3: ( (lv_activity_0_0= ruleActivityStarted ) )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==17) ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // InternalAatDSL.g:349:4: (lv_activity_0_0= ruleActivityStarted )
                    {
                    // InternalAatDSL.g:349:4: (lv_activity_0_0= ruleActivityStarted )
                    // InternalAatDSL.g:350:5: lv_activity_0_0= ruleActivityStarted
                    {

                    					newCompositeNode(grammarAccess.getGivenStatementsAccess().getActivityActivityStartedParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_7);
                    lv_activity_0_0=ruleActivityStarted();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getGivenStatementsRule());
                    					}
                    					set(
                    						current,
                    						"activity",
                    						lv_activity_0_0,
                    						"edu.uned.iss.tfm.AatDSL.ActivityStarted");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;

            }

            // InternalAatDSL.g:367:3: ( (lv_validations_1_0= ruleConditionalStatement ) )+
            int cnt4=0;
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( ((LA4_0>=RULE_COMMENT && LA4_0<=RULE_ID)||(LA4_0>=29 && LA4_0<=30)||LA4_0==34||LA4_0==36||LA4_0==39||LA4_0==41) ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // InternalAatDSL.g:368:4: (lv_validations_1_0= ruleConditionalStatement )
            	    {
            	    // InternalAatDSL.g:368:4: (lv_validations_1_0= ruleConditionalStatement )
            	    // InternalAatDSL.g:369:5: lv_validations_1_0= ruleConditionalStatement
            	    {

            	    					newCompositeNode(grammarAccess.getGivenStatementsAccess().getValidationsConditionalStatementParserRuleCall_1_0());
            	    				
            	    pushFollow(FOLLOW_12);
            	    lv_validations_1_0=ruleConditionalStatement();

            	    state._fsp--;


            	    					if (current==null) {
            	    						current = createModelElementForParent(grammarAccess.getGivenStatementsRule());
            	    					}
            	    					add(
            	    						current,
            	    						"validations",
            	    						lv_validations_1_0,
            	    						"edu.uned.iss.tfm.AatDSL.ConditionalStatement");
            	    					afterParserOrEnumRuleCall();
            	    				

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt4 >= 1 ) break loop4;
                        EarlyExitException eee =
                            new EarlyExitException(4, input);
                        throw eee;
                }
                cnt4++;
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleGivenStatements"


    // $ANTLR start "entryRuleActionsStatements"
    // InternalAatDSL.g:390:1: entryRuleActionsStatements returns [EObject current=null] : iv_ruleActionsStatements= ruleActionsStatements EOF ;
    public final EObject entryRuleActionsStatements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleActionsStatements = null;


        try {
            // InternalAatDSL.g:390:58: (iv_ruleActionsStatements= ruleActionsStatements EOF )
            // InternalAatDSL.g:391:2: iv_ruleActionsStatements= ruleActionsStatements EOF
            {
             newCompositeNode(grammarAccess.getActionsStatementsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleActionsStatements=ruleActionsStatements();

            state._fsp--;

             current =iv_ruleActionsStatements; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleActionsStatements"


    // $ANTLR start "ruleActionsStatements"
    // InternalAatDSL.g:397:1: ruleActionsStatements returns [EObject current=null] : ( (lv_statements_0_0= ruleStatement ) )+ ;
    public final EObject ruleActionsStatements() throws RecognitionException {
        EObject current = null;

        EObject lv_statements_0_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:403:2: ( ( (lv_statements_0_0= ruleStatement ) )+ )
            // InternalAatDSL.g:404:2: ( (lv_statements_0_0= ruleStatement ) )+
            {
            // InternalAatDSL.g:404:2: ( (lv_statements_0_0= ruleStatement ) )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0==RULE_COMMENT||(LA5_0>=18 && LA5_0<=20)||(LA5_0>=22 && LA5_0<=24)||(LA5_0>=26 && LA5_0<=27)) ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // InternalAatDSL.g:405:3: (lv_statements_0_0= ruleStatement )
            	    {
            	    // InternalAatDSL.g:405:3: (lv_statements_0_0= ruleStatement )
            	    // InternalAatDSL.g:406:4: lv_statements_0_0= ruleStatement
            	    {

            	    				newCompositeNode(grammarAccess.getActionsStatementsAccess().getStatementsStatementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_13);
            	    lv_statements_0_0=ruleStatement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getActionsStatementsRule());
            	    				}
            	    				add(
            	    					current,
            	    					"statements",
            	    					lv_statements_0_0,
            	    					"edu.uned.iss.tfm.AatDSL.Statement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleActionsStatements"


    // $ANTLR start "entryRuleThenStatements"
    // InternalAatDSL.g:426:1: entryRuleThenStatements returns [EObject current=null] : iv_ruleThenStatements= ruleThenStatements EOF ;
    public final EObject entryRuleThenStatements() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleThenStatements = null;


        try {
            // InternalAatDSL.g:426:55: (iv_ruleThenStatements= ruleThenStatements EOF )
            // InternalAatDSL.g:427:2: iv_ruleThenStatements= ruleThenStatements EOF
            {
             newCompositeNode(grammarAccess.getThenStatementsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleThenStatements=ruleThenStatements();

            state._fsp--;

             current =iv_ruleThenStatements; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleThenStatements"


    // $ANTLR start "ruleThenStatements"
    // InternalAatDSL.g:433:1: ruleThenStatements returns [EObject current=null] : ( (lv_validations_0_0= ruleConditionalStatement ) )+ ;
    public final EObject ruleThenStatements() throws RecognitionException {
        EObject current = null;

        EObject lv_validations_0_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:439:2: ( ( (lv_validations_0_0= ruleConditionalStatement ) )+ )
            // InternalAatDSL.g:440:2: ( (lv_validations_0_0= ruleConditionalStatement ) )+
            {
            // InternalAatDSL.g:440:2: ( (lv_validations_0_0= ruleConditionalStatement ) )+
            int cnt6=0;
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( ((LA6_0>=RULE_COMMENT && LA6_0<=RULE_ID)||(LA6_0>=29 && LA6_0<=30)||LA6_0==34||LA6_0==36||LA6_0==39||LA6_0==41) ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // InternalAatDSL.g:441:3: (lv_validations_0_0= ruleConditionalStatement )
            	    {
            	    // InternalAatDSL.g:441:3: (lv_validations_0_0= ruleConditionalStatement )
            	    // InternalAatDSL.g:442:4: lv_validations_0_0= ruleConditionalStatement
            	    {

            	    				newCompositeNode(grammarAccess.getThenStatementsAccess().getValidationsConditionalStatementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_12);
            	    lv_validations_0_0=ruleConditionalStatement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getThenStatementsRule());
            	    				}
            	    				add(
            	    					current,
            	    					"validations",
            	    					lv_validations_0_0,
            	    					"edu.uned.iss.tfm.AatDSL.ConditionalStatement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt6 >= 1 ) break loop6;
                        EarlyExitException eee =
                            new EarlyExitException(6, input);
                        throw eee;
                }
                cnt6++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleThenStatements"


    // $ANTLR start "entryRuleStatement"
    // InternalAatDSL.g:462:1: entryRuleStatement returns [EObject current=null] : iv_ruleStatement= ruleStatement EOF ;
    public final EObject entryRuleStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleStatement = null;


        try {
            // InternalAatDSL.g:462:50: (iv_ruleStatement= ruleStatement EOF )
            // InternalAatDSL.g:463:2: iv_ruleStatement= ruleStatement EOF
            {
             newCompositeNode(grammarAccess.getStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleStatement=ruleStatement();

            state._fsp--;

             current =iv_ruleStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleStatement"


    // $ANTLR start "ruleStatement"
    // InternalAatDSL.g:469:1: ruleStatement returns [EObject current=null] : (this_InputText_0= ruleInputText | this_ButtonPress_1= ruleButtonPress | this_OptionChoose_2= ruleOptionChoose | this_ValueSelect_3= ruleValueSelect | ( () this_COMMENT_5= RULE_COMMENT ) ) ;
    public final EObject ruleStatement() throws RecognitionException {
        EObject current = null;

        Token this_COMMENT_5=null;
        EObject this_InputText_0 = null;

        EObject this_ButtonPress_1 = null;

        EObject this_OptionChoose_2 = null;

        EObject this_ValueSelect_3 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:475:2: ( (this_InputText_0= ruleInputText | this_ButtonPress_1= ruleButtonPress | this_OptionChoose_2= ruleOptionChoose | this_ValueSelect_3= ruleValueSelect | ( () this_COMMENT_5= RULE_COMMENT ) ) )
            // InternalAatDSL.g:476:2: (this_InputText_0= ruleInputText | this_ButtonPress_1= ruleButtonPress | this_OptionChoose_2= ruleOptionChoose | this_ValueSelect_3= ruleValueSelect | ( () this_COMMENT_5= RULE_COMMENT ) )
            {
            // InternalAatDSL.g:476:2: (this_InputText_0= ruleInputText | this_ButtonPress_1= ruleButtonPress | this_OptionChoose_2= ruleOptionChoose | this_ValueSelect_3= ruleValueSelect | ( () this_COMMENT_5= RULE_COMMENT ) )
            int alt7=5;
            switch ( input.LA(1) ) {
            case 18:
                {
                switch ( input.LA(2) ) {
                case 19:
                case 20:
                    {
                    alt7=1;
                    }
                    break;
                case 26:
                    {
                    alt7=3;
                    }
                    break;
                case 27:
                    {
                    alt7=4;
                    }
                    break;
                case 22:
                case 23:
                case 24:
                    {
                    alt7=2;
                    }
                    break;
                default:
                    NoViableAltException nvae =
                        new NoViableAltException("", 7, 1, input);

                    throw nvae;
                }

                }
                break;
            case 19:
            case 20:
                {
                alt7=1;
                }
                break;
            case 22:
            case 23:
            case 24:
                {
                alt7=2;
                }
                break;
            case 26:
                {
                alt7=3;
                }
                break;
            case 27:
                {
                alt7=4;
                }
                break;
            case RULE_COMMENT:
                {
                alt7=5;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 7, 0, input);

                throw nvae;
            }

            switch (alt7) {
                case 1 :
                    // InternalAatDSL.g:477:3: this_InputText_0= ruleInputText
                    {

                    			newCompositeNode(grammarAccess.getStatementAccess().getInputTextParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_InputText_0=ruleInputText();

                    state._fsp--;


                    			current = this_InputText_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalAatDSL.g:486:3: this_ButtonPress_1= ruleButtonPress
                    {

                    			newCompositeNode(grammarAccess.getStatementAccess().getButtonPressParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_ButtonPress_1=ruleButtonPress();

                    state._fsp--;


                    			current = this_ButtonPress_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalAatDSL.g:495:3: this_OptionChoose_2= ruleOptionChoose
                    {

                    			newCompositeNode(grammarAccess.getStatementAccess().getOptionChooseParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_OptionChoose_2=ruleOptionChoose();

                    state._fsp--;


                    			current = this_OptionChoose_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalAatDSL.g:504:3: this_ValueSelect_3= ruleValueSelect
                    {

                    			newCompositeNode(grammarAccess.getStatementAccess().getValueSelectParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValueSelect_3=ruleValueSelect();

                    state._fsp--;


                    			current = this_ValueSelect_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalAatDSL.g:513:3: ( () this_COMMENT_5= RULE_COMMENT )
                    {
                    // InternalAatDSL.g:513:3: ( () this_COMMENT_5= RULE_COMMENT )
                    // InternalAatDSL.g:514:4: () this_COMMENT_5= RULE_COMMENT
                    {
                    // InternalAatDSL.g:514:4: ()
                    // InternalAatDSL.g:515:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getStatementAccess().getStatementAction_4_0(),
                    						current);
                    				

                    }

                    this_COMMENT_5=(Token)match(input,RULE_COMMENT,FOLLOW_2); 

                    				newLeafNode(this_COMMENT_5, grammarAccess.getStatementAccess().getCOMMENTTerminalRuleCall_4_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleStatement"


    // $ANTLR start "entryRuleInputText"
    // InternalAatDSL.g:530:1: entryRuleInputText returns [EObject current=null] : iv_ruleInputText= ruleInputText EOF ;
    public final EObject entryRuleInputText() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInputText = null;


        try {
            // InternalAatDSL.g:530:50: (iv_ruleInputText= ruleInputText EOF )
            // InternalAatDSL.g:531:2: iv_ruleInputText= ruleInputText EOF
            {
             newCompositeNode(grammarAccess.getInputTextRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInputText=ruleInputText();

            state._fsp--;

             current =iv_ruleInputText; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInputText"


    // $ANTLR start "ruleInputText"
    // InternalAatDSL.g:537:1: ruleInputText returns [EObject current=null] : ( (otherlv_0= 'I' )? (otherlv_1= 'type' | otherlv_2= 'input' ) ( (lv_value_3_0= ruleVALUE ) ) otherlv_4= 'into' ( (lv_name_5_0= ruleANDROID_ID ) ) ) ;
    public final EObject ruleInputText() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_value_3_0 = null;

        AntlrDatatypeRuleToken lv_name_5_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:543:2: ( ( (otherlv_0= 'I' )? (otherlv_1= 'type' | otherlv_2= 'input' ) ( (lv_value_3_0= ruleVALUE ) ) otherlv_4= 'into' ( (lv_name_5_0= ruleANDROID_ID ) ) ) )
            // InternalAatDSL.g:544:2: ( (otherlv_0= 'I' )? (otherlv_1= 'type' | otherlv_2= 'input' ) ( (lv_value_3_0= ruleVALUE ) ) otherlv_4= 'into' ( (lv_name_5_0= ruleANDROID_ID ) ) )
            {
            // InternalAatDSL.g:544:2: ( (otherlv_0= 'I' )? (otherlv_1= 'type' | otherlv_2= 'input' ) ( (lv_value_3_0= ruleVALUE ) ) otherlv_4= 'into' ( (lv_name_5_0= ruleANDROID_ID ) ) )
            // InternalAatDSL.g:545:3: (otherlv_0= 'I' )? (otherlv_1= 'type' | otherlv_2= 'input' ) ( (lv_value_3_0= ruleVALUE ) ) otherlv_4= 'into' ( (lv_name_5_0= ruleANDROID_ID ) )
            {
            // InternalAatDSL.g:545:3: (otherlv_0= 'I' )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0==18) ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // InternalAatDSL.g:546:4: otherlv_0= 'I'
                    {
                    otherlv_0=(Token)match(input,18,FOLLOW_14); 

                    				newLeafNode(otherlv_0, grammarAccess.getInputTextAccess().getIKeyword_0());
                    			

                    }
                    break;

            }

            // InternalAatDSL.g:551:3: (otherlv_1= 'type' | otherlv_2= 'input' )
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( (LA9_0==19) ) {
                alt9=1;
            }
            else if ( (LA9_0==20) ) {
                alt9=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 9, 0, input);

                throw nvae;
            }
            switch (alt9) {
                case 1 :
                    // InternalAatDSL.g:552:4: otherlv_1= 'type'
                    {
                    otherlv_1=(Token)match(input,19,FOLLOW_15); 

                    				newLeafNode(otherlv_1, grammarAccess.getInputTextAccess().getTypeKeyword_1_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalAatDSL.g:557:4: otherlv_2= 'input'
                    {
                    otherlv_2=(Token)match(input,20,FOLLOW_15); 

                    				newLeafNode(otherlv_2, grammarAccess.getInputTextAccess().getInputKeyword_1_1());
                    			

                    }
                    break;

            }

            // InternalAatDSL.g:562:3: ( (lv_value_3_0= ruleVALUE ) )
            // InternalAatDSL.g:563:4: (lv_value_3_0= ruleVALUE )
            {
            // InternalAatDSL.g:563:4: (lv_value_3_0= ruleVALUE )
            // InternalAatDSL.g:564:5: lv_value_3_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getInputTextAccess().getValueVALUEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_16);
            lv_value_3_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInputTextRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_3_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_4=(Token)match(input,21,FOLLOW_11); 

            			newLeafNode(otherlv_4, grammarAccess.getInputTextAccess().getIntoKeyword_3());
            		
            // InternalAatDSL.g:585:3: ( (lv_name_5_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:586:4: (lv_name_5_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:586:4: (lv_name_5_0= ruleANDROID_ID )
            // InternalAatDSL.g:587:5: lv_name_5_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getInputTextAccess().getNameANDROID_IDParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_5_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getInputTextRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_5_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInputText"


    // $ANTLR start "entryRuleButtonPress"
    // InternalAatDSL.g:608:1: entryRuleButtonPress returns [EObject current=null] : iv_ruleButtonPress= ruleButtonPress EOF ;
    public final EObject entryRuleButtonPress() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleButtonPress = null;


        try {
            // InternalAatDSL.g:608:52: (iv_ruleButtonPress= ruleButtonPress EOF )
            // InternalAatDSL.g:609:2: iv_ruleButtonPress= ruleButtonPress EOF
            {
             newCompositeNode(grammarAccess.getButtonPressRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleButtonPress=ruleButtonPress();

            state._fsp--;

             current =iv_ruleButtonPress; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleButtonPress"


    // $ANTLR start "ruleButtonPress"
    // InternalAatDSL.g:615:1: ruleButtonPress returns [EObject current=null] : ( (otherlv_0= 'I' )? (otherlv_1= 'tap' | otherlv_2= 'press' | otherlv_3= 'click' ) otherlv_4= 'over' ( (lv_name_5_0= ruleANDROID_ID ) ) ) ;
    public final EObject ruleButtonPress() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_name_5_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:621:2: ( ( (otherlv_0= 'I' )? (otherlv_1= 'tap' | otherlv_2= 'press' | otherlv_3= 'click' ) otherlv_4= 'over' ( (lv_name_5_0= ruleANDROID_ID ) ) ) )
            // InternalAatDSL.g:622:2: ( (otherlv_0= 'I' )? (otherlv_1= 'tap' | otherlv_2= 'press' | otherlv_3= 'click' ) otherlv_4= 'over' ( (lv_name_5_0= ruleANDROID_ID ) ) )
            {
            // InternalAatDSL.g:622:2: ( (otherlv_0= 'I' )? (otherlv_1= 'tap' | otherlv_2= 'press' | otherlv_3= 'click' ) otherlv_4= 'over' ( (lv_name_5_0= ruleANDROID_ID ) ) )
            // InternalAatDSL.g:623:3: (otherlv_0= 'I' )? (otherlv_1= 'tap' | otherlv_2= 'press' | otherlv_3= 'click' ) otherlv_4= 'over' ( (lv_name_5_0= ruleANDROID_ID ) )
            {
            // InternalAatDSL.g:623:3: (otherlv_0= 'I' )?
            int alt10=2;
            int LA10_0 = input.LA(1);

            if ( (LA10_0==18) ) {
                alt10=1;
            }
            switch (alt10) {
                case 1 :
                    // InternalAatDSL.g:624:4: otherlv_0= 'I'
                    {
                    otherlv_0=(Token)match(input,18,FOLLOW_17); 

                    				newLeafNode(otherlv_0, grammarAccess.getButtonPressAccess().getIKeyword_0());
                    			

                    }
                    break;

            }

            // InternalAatDSL.g:629:3: (otherlv_1= 'tap' | otherlv_2= 'press' | otherlv_3= 'click' )
            int alt11=3;
            switch ( input.LA(1) ) {
            case 22:
                {
                alt11=1;
                }
                break;
            case 23:
                {
                alt11=2;
                }
                break;
            case 24:
                {
                alt11=3;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 11, 0, input);

                throw nvae;
            }

            switch (alt11) {
                case 1 :
                    // InternalAatDSL.g:630:4: otherlv_1= 'tap'
                    {
                    otherlv_1=(Token)match(input,22,FOLLOW_18); 

                    				newLeafNode(otherlv_1, grammarAccess.getButtonPressAccess().getTapKeyword_1_0());
                    			

                    }
                    break;
                case 2 :
                    // InternalAatDSL.g:635:4: otherlv_2= 'press'
                    {
                    otherlv_2=(Token)match(input,23,FOLLOW_18); 

                    				newLeafNode(otherlv_2, grammarAccess.getButtonPressAccess().getPressKeyword_1_1());
                    			

                    }
                    break;
                case 3 :
                    // InternalAatDSL.g:640:4: otherlv_3= 'click'
                    {
                    otherlv_3=(Token)match(input,24,FOLLOW_18); 

                    				newLeafNode(otherlv_3, grammarAccess.getButtonPressAccess().getClickKeyword_1_2());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,25,FOLLOW_11); 

            			newLeafNode(otherlv_4, grammarAccess.getButtonPressAccess().getOverKeyword_2());
            		
            // InternalAatDSL.g:649:3: ( (lv_name_5_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:650:4: (lv_name_5_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:650:4: (lv_name_5_0= ruleANDROID_ID )
            // InternalAatDSL.g:651:5: lv_name_5_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getButtonPressAccess().getNameANDROID_IDParserRuleCall_3_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_5_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getButtonPressRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_5_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleButtonPress"


    // $ANTLR start "entryRuleOptionChoose"
    // InternalAatDSL.g:672:1: entryRuleOptionChoose returns [EObject current=null] : iv_ruleOptionChoose= ruleOptionChoose EOF ;
    public final EObject entryRuleOptionChoose() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOptionChoose = null;


        try {
            // InternalAatDSL.g:672:53: (iv_ruleOptionChoose= ruleOptionChoose EOF )
            // InternalAatDSL.g:673:2: iv_ruleOptionChoose= ruleOptionChoose EOF
            {
             newCompositeNode(grammarAccess.getOptionChooseRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOptionChoose=ruleOptionChoose();

            state._fsp--;

             current =iv_ruleOptionChoose; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOptionChoose"


    // $ANTLR start "ruleOptionChoose"
    // InternalAatDSL.g:679:1: ruleOptionChoose returns [EObject current=null] : ( (otherlv_0= 'I' )? otherlv_1= 'choose' ( (lv_value_2_0= ruleVALUE ) ) ) ;
    public final EObject ruleOptionChoose() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_value_2_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:685:2: ( ( (otherlv_0= 'I' )? otherlv_1= 'choose' ( (lv_value_2_0= ruleVALUE ) ) ) )
            // InternalAatDSL.g:686:2: ( (otherlv_0= 'I' )? otherlv_1= 'choose' ( (lv_value_2_0= ruleVALUE ) ) )
            {
            // InternalAatDSL.g:686:2: ( (otherlv_0= 'I' )? otherlv_1= 'choose' ( (lv_value_2_0= ruleVALUE ) ) )
            // InternalAatDSL.g:687:3: (otherlv_0= 'I' )? otherlv_1= 'choose' ( (lv_value_2_0= ruleVALUE ) )
            {
            // InternalAatDSL.g:687:3: (otherlv_0= 'I' )?
            int alt12=2;
            int LA12_0 = input.LA(1);

            if ( (LA12_0==18) ) {
                alt12=1;
            }
            switch (alt12) {
                case 1 :
                    // InternalAatDSL.g:688:4: otherlv_0= 'I'
                    {
                    otherlv_0=(Token)match(input,18,FOLLOW_19); 

                    				newLeafNode(otherlv_0, grammarAccess.getOptionChooseAccess().getIKeyword_0());
                    			

                    }
                    break;

            }

            otherlv_1=(Token)match(input,26,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getOptionChooseAccess().getChooseKeyword_1());
            		
            // InternalAatDSL.g:697:3: ( (lv_value_2_0= ruleVALUE ) )
            // InternalAatDSL.g:698:4: (lv_value_2_0= ruleVALUE )
            {
            // InternalAatDSL.g:698:4: (lv_value_2_0= ruleVALUE )
            // InternalAatDSL.g:699:5: lv_value_2_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getOptionChooseAccess().getValueVALUEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_2_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOptionChooseRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOptionChoose"


    // $ANTLR start "entryRuleValueSelect"
    // InternalAatDSL.g:720:1: entryRuleValueSelect returns [EObject current=null] : iv_ruleValueSelect= ruleValueSelect EOF ;
    public final EObject entryRuleValueSelect() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueSelect = null;


        try {
            // InternalAatDSL.g:720:52: (iv_ruleValueSelect= ruleValueSelect EOF )
            // InternalAatDSL.g:721:2: iv_ruleValueSelect= ruleValueSelect EOF
            {
             newCompositeNode(grammarAccess.getValueSelectRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueSelect=ruleValueSelect();

            state._fsp--;

             current =iv_ruleValueSelect; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueSelect"


    // $ANTLR start "ruleValueSelect"
    // InternalAatDSL.g:727:1: ruleValueSelect returns [EObject current=null] : ( (otherlv_0= 'I' )? otherlv_1= 'select' ( (lv_value_2_0= ruleVALUE ) ) otherlv_3= 'in' ( (lv_name_4_0= ruleANDROID_ID ) ) ) ;
    public final EObject ruleValueSelect() throws RecognitionException {
        EObject current = null;

        Token otherlv_0=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        AntlrDatatypeRuleToken lv_value_2_0 = null;

        AntlrDatatypeRuleToken lv_name_4_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:733:2: ( ( (otherlv_0= 'I' )? otherlv_1= 'select' ( (lv_value_2_0= ruleVALUE ) ) otherlv_3= 'in' ( (lv_name_4_0= ruleANDROID_ID ) ) ) )
            // InternalAatDSL.g:734:2: ( (otherlv_0= 'I' )? otherlv_1= 'select' ( (lv_value_2_0= ruleVALUE ) ) otherlv_3= 'in' ( (lv_name_4_0= ruleANDROID_ID ) ) )
            {
            // InternalAatDSL.g:734:2: ( (otherlv_0= 'I' )? otherlv_1= 'select' ( (lv_value_2_0= ruleVALUE ) ) otherlv_3= 'in' ( (lv_name_4_0= ruleANDROID_ID ) ) )
            // InternalAatDSL.g:735:3: (otherlv_0= 'I' )? otherlv_1= 'select' ( (lv_value_2_0= ruleVALUE ) ) otherlv_3= 'in' ( (lv_name_4_0= ruleANDROID_ID ) )
            {
            // InternalAatDSL.g:735:3: (otherlv_0= 'I' )?
            int alt13=2;
            int LA13_0 = input.LA(1);

            if ( (LA13_0==18) ) {
                alt13=1;
            }
            switch (alt13) {
                case 1 :
                    // InternalAatDSL.g:736:4: otherlv_0= 'I'
                    {
                    otherlv_0=(Token)match(input,18,FOLLOW_20); 

                    				newLeafNode(otherlv_0, grammarAccess.getValueSelectAccess().getIKeyword_0());
                    			

                    }
                    break;

            }

            otherlv_1=(Token)match(input,27,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getValueSelectAccess().getSelectKeyword_1());
            		
            // InternalAatDSL.g:745:3: ( (lv_value_2_0= ruleVALUE ) )
            // InternalAatDSL.g:746:4: (lv_value_2_0= ruleVALUE )
            {
            // InternalAatDSL.g:746:4: (lv_value_2_0= ruleVALUE )
            // InternalAatDSL.g:747:5: lv_value_2_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getValueSelectAccess().getValueVALUEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_21);
            lv_value_2_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getValueSelectRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_3=(Token)match(input,28,FOLLOW_11); 

            			newLeafNode(otherlv_3, grammarAccess.getValueSelectAccess().getInKeyword_3());
            		
            // InternalAatDSL.g:768:3: ( (lv_name_4_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:769:4: (lv_name_4_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:769:4: (lv_name_4_0= ruleANDROID_ID )
            // InternalAatDSL.g:770:5: lv_name_4_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getValueSelectAccess().getNameANDROID_IDParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_4_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getValueSelectRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_4_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueSelect"


    // $ANTLR start "entryRuleConditionalStatement"
    // InternalAatDSL.g:791:1: entryRuleConditionalStatement returns [EObject current=null] : iv_ruleConditionalStatement= ruleConditionalStatement EOF ;
    public final EObject entryRuleConditionalStatement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleConditionalStatement = null;


        try {
            // InternalAatDSL.g:791:61: (iv_ruleConditionalStatement= ruleConditionalStatement EOF )
            // InternalAatDSL.g:792:2: iv_ruleConditionalStatement= ruleConditionalStatement EOF
            {
             newCompositeNode(grammarAccess.getConditionalStatementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleConditionalStatement=ruleConditionalStatement();

            state._fsp--;

             current =iv_ruleConditionalStatement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleConditionalStatement"


    // $ANTLR start "ruleConditionalStatement"
    // InternalAatDSL.g:798:1: ruleConditionalStatement returns [EObject current=null] : (this_IsEnabled_0= ruleIsEnabled | this_IsVisible_1= ruleIsVisible | this_OptionIsChecked_2= ruleOptionIsChecked | this_ValueIsSelected_3= ruleValueIsSelected | this_MessageIsDisplayed_4= ruleMessageIsDisplayed | this_TextContains_5= ruleTextContains | ( () this_COMMENT_7= RULE_COMMENT ) ) ;
    public final EObject ruleConditionalStatement() throws RecognitionException {
        EObject current = null;

        Token this_COMMENT_7=null;
        EObject this_IsEnabled_0 = null;

        EObject this_IsVisible_1 = null;

        EObject this_OptionIsChecked_2 = null;

        EObject this_ValueIsSelected_3 = null;

        EObject this_MessageIsDisplayed_4 = null;

        EObject this_TextContains_5 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:804:2: ( (this_IsEnabled_0= ruleIsEnabled | this_IsVisible_1= ruleIsVisible | this_OptionIsChecked_2= ruleOptionIsChecked | this_ValueIsSelected_3= ruleValueIsSelected | this_MessageIsDisplayed_4= ruleMessageIsDisplayed | this_TextContains_5= ruleTextContains | ( () this_COMMENT_7= RULE_COMMENT ) ) )
            // InternalAatDSL.g:805:2: (this_IsEnabled_0= ruleIsEnabled | this_IsVisible_1= ruleIsVisible | this_OptionIsChecked_2= ruleOptionIsChecked | this_ValueIsSelected_3= ruleValueIsSelected | this_MessageIsDisplayed_4= ruleMessageIsDisplayed | this_TextContains_5= ruleTextContains | ( () this_COMMENT_7= RULE_COMMENT ) )
            {
            // InternalAatDSL.g:805:2: (this_IsEnabled_0= ruleIsEnabled | this_IsVisible_1= ruleIsVisible | this_OptionIsChecked_2= ruleOptionIsChecked | this_ValueIsSelected_3= ruleValueIsSelected | this_MessageIsDisplayed_4= ruleMessageIsDisplayed | this_TextContains_5= ruleTextContains | ( () this_COMMENT_7= RULE_COMMENT ) )
            int alt14=7;
            alt14 = dfa14.predict(input);
            switch (alt14) {
                case 1 :
                    // InternalAatDSL.g:806:3: this_IsEnabled_0= ruleIsEnabled
                    {

                    			newCompositeNode(grammarAccess.getConditionalStatementAccess().getIsEnabledParserRuleCall_0());
                    		
                    pushFollow(FOLLOW_2);
                    this_IsEnabled_0=ruleIsEnabled();

                    state._fsp--;


                    			current = this_IsEnabled_0;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 2 :
                    // InternalAatDSL.g:815:3: this_IsVisible_1= ruleIsVisible
                    {

                    			newCompositeNode(grammarAccess.getConditionalStatementAccess().getIsVisibleParserRuleCall_1());
                    		
                    pushFollow(FOLLOW_2);
                    this_IsVisible_1=ruleIsVisible();

                    state._fsp--;


                    			current = this_IsVisible_1;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 3 :
                    // InternalAatDSL.g:824:3: this_OptionIsChecked_2= ruleOptionIsChecked
                    {

                    			newCompositeNode(grammarAccess.getConditionalStatementAccess().getOptionIsCheckedParserRuleCall_2());
                    		
                    pushFollow(FOLLOW_2);
                    this_OptionIsChecked_2=ruleOptionIsChecked();

                    state._fsp--;


                    			current = this_OptionIsChecked_2;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 4 :
                    // InternalAatDSL.g:833:3: this_ValueIsSelected_3= ruleValueIsSelected
                    {

                    			newCompositeNode(grammarAccess.getConditionalStatementAccess().getValueIsSelectedParserRuleCall_3());
                    		
                    pushFollow(FOLLOW_2);
                    this_ValueIsSelected_3=ruleValueIsSelected();

                    state._fsp--;


                    			current = this_ValueIsSelected_3;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 5 :
                    // InternalAatDSL.g:842:3: this_MessageIsDisplayed_4= ruleMessageIsDisplayed
                    {

                    			newCompositeNode(grammarAccess.getConditionalStatementAccess().getMessageIsDisplayedParserRuleCall_4());
                    		
                    pushFollow(FOLLOW_2);
                    this_MessageIsDisplayed_4=ruleMessageIsDisplayed();

                    state._fsp--;


                    			current = this_MessageIsDisplayed_4;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 6 :
                    // InternalAatDSL.g:851:3: this_TextContains_5= ruleTextContains
                    {

                    			newCompositeNode(grammarAccess.getConditionalStatementAccess().getTextContainsParserRuleCall_5());
                    		
                    pushFollow(FOLLOW_2);
                    this_TextContains_5=ruleTextContains();

                    state._fsp--;


                    			current = this_TextContains_5;
                    			afterParserOrEnumRuleCall();
                    		

                    }
                    break;
                case 7 :
                    // InternalAatDSL.g:860:3: ( () this_COMMENT_7= RULE_COMMENT )
                    {
                    // InternalAatDSL.g:860:3: ( () this_COMMENT_7= RULE_COMMENT )
                    // InternalAatDSL.g:861:4: () this_COMMENT_7= RULE_COMMENT
                    {
                    // InternalAatDSL.g:861:4: ()
                    // InternalAatDSL.g:862:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getConditionalStatementAccess().getConditionalStatementAction_6_0(),
                    						current);
                    				

                    }

                    this_COMMENT_7=(Token)match(input,RULE_COMMENT,FOLLOW_2); 

                    				newLeafNode(this_COMMENT_7, grammarAccess.getConditionalStatementAccess().getCOMMENTTerminalRuleCall_6_1());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleConditionalStatement"


    // $ANTLR start "entryRuleIsEnabled"
    // InternalAatDSL.g:877:1: entryRuleIsEnabled returns [EObject current=null] : iv_ruleIsEnabled= ruleIsEnabled EOF ;
    public final EObject entryRuleIsEnabled() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIsEnabled = null;


        try {
            // InternalAatDSL.g:877:50: (iv_ruleIsEnabled= ruleIsEnabled EOF )
            // InternalAatDSL.g:878:2: iv_ruleIsEnabled= ruleIsEnabled EOF
            {
             newCompositeNode(grammarAccess.getIsEnabledRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIsEnabled=ruleIsEnabled();

            state._fsp--;

             current =iv_ruleIsEnabled; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIsEnabled"


    // $ANTLR start "ruleIsEnabled"
    // InternalAatDSL.g:884:1: ruleIsEnabled returns [EObject current=null] : ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'enabled' ) ;
    public final EObject ruleIsEnabled() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_1=null;
        Token lv_op_0_2=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:890:2: ( ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'enabled' ) )
            // InternalAatDSL.g:891:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'enabled' )
            {
            // InternalAatDSL.g:891:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'enabled' )
            // InternalAatDSL.g:892:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'enabled'
            {
            // InternalAatDSL.g:892:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )?
            int alt16=2;
            int LA16_0 = input.LA(1);

            if ( ((LA16_0>=29 && LA16_0<=30)) ) {
                alt16=1;
            }
            switch (alt16) {
                case 1 :
                    // InternalAatDSL.g:893:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    {
                    // InternalAatDSL.g:893:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    // InternalAatDSL.g:894:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    {
                    // InternalAatDSL.g:894:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    int alt15=2;
                    int LA15_0 = input.LA(1);

                    if ( (LA15_0==29) ) {
                        alt15=1;
                    }
                    else if ( (LA15_0==30) ) {
                        alt15=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 15, 0, input);

                        throw nvae;
                    }
                    switch (alt15) {
                        case 1 :
                            // InternalAatDSL.g:895:6: lv_op_0_1= 'And'
                            {
                            lv_op_0_1=(Token)match(input,29,FOLLOW_11); 

                            						newLeafNode(lv_op_0_1, grammarAccess.getIsEnabledAccess().getOpAndKeyword_0_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getIsEnabledRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_1, null);
                            					

                            }
                            break;
                        case 2 :
                            // InternalAatDSL.g:906:6: lv_op_0_2= 'But'
                            {
                            lv_op_0_2=(Token)match(input,30,FOLLOW_11); 

                            						newLeafNode(lv_op_0_2, grammarAccess.getIsEnabledAccess().getOpButKeyword_0_0_1());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getIsEnabledRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_2, null);
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            // InternalAatDSL.g:919:3: ( (lv_name_1_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:920:4: (lv_name_1_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:920:4: (lv_name_1_0= ruleANDROID_ID )
            // InternalAatDSL.g:921:5: lv_name_1_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getIsEnabledAccess().getNameANDROID_IDParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_22);
            lv_name_1_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIsEnabledRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,31,FOLLOW_23); 

            			newLeafNode(otherlv_2, grammarAccess.getIsEnabledAccess().getIsKeyword_2());
            		
            otherlv_3=(Token)match(input,32,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getIsEnabledAccess().getEnabledKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIsEnabled"


    // $ANTLR start "entryRuleIsVisible"
    // InternalAatDSL.g:950:1: entryRuleIsVisible returns [EObject current=null] : iv_ruleIsVisible= ruleIsVisible EOF ;
    public final EObject entryRuleIsVisible() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleIsVisible = null;


        try {
            // InternalAatDSL.g:950:50: (iv_ruleIsVisible= ruleIsVisible EOF )
            // InternalAatDSL.g:951:2: iv_ruleIsVisible= ruleIsVisible EOF
            {
             newCompositeNode(grammarAccess.getIsVisibleRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleIsVisible=ruleIsVisible();

            state._fsp--;

             current =iv_ruleIsVisible; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleIsVisible"


    // $ANTLR start "ruleIsVisible"
    // InternalAatDSL.g:957:1: ruleIsVisible returns [EObject current=null] : ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'visible' ) ;
    public final EObject ruleIsVisible() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_1=null;
        Token lv_op_0_2=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        AntlrDatatypeRuleToken lv_name_1_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:963:2: ( ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'visible' ) )
            // InternalAatDSL.g:964:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'visible' )
            {
            // InternalAatDSL.g:964:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'visible' )
            // InternalAatDSL.g:965:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? ( (lv_name_1_0= ruleANDROID_ID ) ) otherlv_2= 'is' otherlv_3= 'visible'
            {
            // InternalAatDSL.g:965:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )?
            int alt18=2;
            int LA18_0 = input.LA(1);

            if ( ((LA18_0>=29 && LA18_0<=30)) ) {
                alt18=1;
            }
            switch (alt18) {
                case 1 :
                    // InternalAatDSL.g:966:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    {
                    // InternalAatDSL.g:966:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    // InternalAatDSL.g:967:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    {
                    // InternalAatDSL.g:967:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    int alt17=2;
                    int LA17_0 = input.LA(1);

                    if ( (LA17_0==29) ) {
                        alt17=1;
                    }
                    else if ( (LA17_0==30) ) {
                        alt17=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 17, 0, input);

                        throw nvae;
                    }
                    switch (alt17) {
                        case 1 :
                            // InternalAatDSL.g:968:6: lv_op_0_1= 'And'
                            {
                            lv_op_0_1=(Token)match(input,29,FOLLOW_11); 

                            						newLeafNode(lv_op_0_1, grammarAccess.getIsVisibleAccess().getOpAndKeyword_0_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getIsVisibleRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_1, null);
                            					

                            }
                            break;
                        case 2 :
                            // InternalAatDSL.g:979:6: lv_op_0_2= 'But'
                            {
                            lv_op_0_2=(Token)match(input,30,FOLLOW_11); 

                            						newLeafNode(lv_op_0_2, grammarAccess.getIsVisibleAccess().getOpButKeyword_0_0_1());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getIsVisibleRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_2, null);
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            // InternalAatDSL.g:992:3: ( (lv_name_1_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:993:4: (lv_name_1_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:993:4: (lv_name_1_0= ruleANDROID_ID )
            // InternalAatDSL.g:994:5: lv_name_1_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getIsVisibleAccess().getNameANDROID_IDParserRuleCall_1_0());
            				
            pushFollow(FOLLOW_22);
            lv_name_1_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getIsVisibleRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_1_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            otherlv_2=(Token)match(input,31,FOLLOW_24); 

            			newLeafNode(otherlv_2, grammarAccess.getIsVisibleAccess().getIsKeyword_2());
            		
            otherlv_3=(Token)match(input,33,FOLLOW_2); 

            			newLeafNode(otherlv_3, grammarAccess.getIsVisibleAccess().getVisibleKeyword_3());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleIsVisible"


    // $ANTLR start "entryRuleOptionIsChecked"
    // InternalAatDSL.g:1023:1: entryRuleOptionIsChecked returns [EObject current=null] : iv_ruleOptionIsChecked= ruleOptionIsChecked EOF ;
    public final EObject entryRuleOptionIsChecked() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleOptionIsChecked = null;


        try {
            // InternalAatDSL.g:1023:56: (iv_ruleOptionIsChecked= ruleOptionIsChecked EOF )
            // InternalAatDSL.g:1024:2: iv_ruleOptionIsChecked= ruleOptionIsChecked EOF
            {
             newCompositeNode(grammarAccess.getOptionIsCheckedRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleOptionIsChecked=ruleOptionIsChecked();

            state._fsp--;

             current =iv_ruleOptionIsChecked; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleOptionIsChecked"


    // $ANTLR start "ruleOptionIsChecked"
    // InternalAatDSL.g:1030:1: ruleOptionIsChecked returns [EObject current=null] : ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Option' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'checked' ) ;
    public final EObject ruleOptionIsChecked() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_1=null;
        Token lv_op_0_2=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_value_2_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:1036:2: ( ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Option' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'checked' ) )
            // InternalAatDSL.g:1037:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Option' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'checked' )
            {
            // InternalAatDSL.g:1037:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Option' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'checked' )
            // InternalAatDSL.g:1038:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Option' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'checked'
            {
            // InternalAatDSL.g:1038:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )?
            int alt20=2;
            int LA20_0 = input.LA(1);

            if ( ((LA20_0>=29 && LA20_0<=30)) ) {
                alt20=1;
            }
            switch (alt20) {
                case 1 :
                    // InternalAatDSL.g:1039:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    {
                    // InternalAatDSL.g:1039:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    // InternalAatDSL.g:1040:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    {
                    // InternalAatDSL.g:1040:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    int alt19=2;
                    int LA19_0 = input.LA(1);

                    if ( (LA19_0==29) ) {
                        alt19=1;
                    }
                    else if ( (LA19_0==30) ) {
                        alt19=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 19, 0, input);

                        throw nvae;
                    }
                    switch (alt19) {
                        case 1 :
                            // InternalAatDSL.g:1041:6: lv_op_0_1= 'And'
                            {
                            lv_op_0_1=(Token)match(input,29,FOLLOW_25); 

                            						newLeafNode(lv_op_0_1, grammarAccess.getOptionIsCheckedAccess().getOpAndKeyword_0_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getOptionIsCheckedRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_1, null);
                            					

                            }
                            break;
                        case 2 :
                            // InternalAatDSL.g:1052:6: lv_op_0_2= 'But'
                            {
                            lv_op_0_2=(Token)match(input,30,FOLLOW_25); 

                            						newLeafNode(lv_op_0_2, grammarAccess.getOptionIsCheckedAccess().getOpButKeyword_0_0_1());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getOptionIsCheckedRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_2, null);
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,34,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getOptionIsCheckedAccess().getOptionKeyword_1());
            		
            // InternalAatDSL.g:1069:3: ( (lv_value_2_0= ruleVALUE ) )
            // InternalAatDSL.g:1070:4: (lv_value_2_0= ruleVALUE )
            {
            // InternalAatDSL.g:1070:4: (lv_value_2_0= ruleVALUE )
            // InternalAatDSL.g:1071:5: lv_value_2_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getOptionIsCheckedAccess().getValueVALUEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_26);
            lv_value_2_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getOptionIsCheckedRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAatDSL.g:1088:3: (otherlv_3= 'is' )?
            int alt21=2;
            int LA21_0 = input.LA(1);

            if ( (LA21_0==31) ) {
                alt21=1;
            }
            switch (alt21) {
                case 1 :
                    // InternalAatDSL.g:1089:4: otherlv_3= 'is'
                    {
                    otherlv_3=(Token)match(input,31,FOLLOW_27); 

                    				newLeafNode(otherlv_3, grammarAccess.getOptionIsCheckedAccess().getIsKeyword_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,35,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getOptionIsCheckedAccess().getCheckedKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleOptionIsChecked"


    // $ANTLR start "entryRuleValueIsSelected"
    // InternalAatDSL.g:1102:1: entryRuleValueIsSelected returns [EObject current=null] : iv_ruleValueIsSelected= ruleValueIsSelected EOF ;
    public final EObject entryRuleValueIsSelected() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleValueIsSelected = null;


        try {
            // InternalAatDSL.g:1102:56: (iv_ruleValueIsSelected= ruleValueIsSelected EOF )
            // InternalAatDSL.g:1103:2: iv_ruleValueIsSelected= ruleValueIsSelected EOF
            {
             newCompositeNode(grammarAccess.getValueIsSelectedRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleValueIsSelected=ruleValueIsSelected();

            state._fsp--;

             current =iv_ruleValueIsSelected; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleValueIsSelected"


    // $ANTLR start "ruleValueIsSelected"
    // InternalAatDSL.g:1109:1: ruleValueIsSelected returns [EObject current=null] : ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Value' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'selected' (otherlv_5= 'at' )? ( (lv_name_6_0= ruleANDROID_ID ) ) ) ;
    public final EObject ruleValueIsSelected() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_1=null;
        Token lv_op_0_2=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        AntlrDatatypeRuleToken lv_value_2_0 = null;

        AntlrDatatypeRuleToken lv_name_6_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:1115:2: ( ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Value' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'selected' (otherlv_5= 'at' )? ( (lv_name_6_0= ruleANDROID_ID ) ) ) )
            // InternalAatDSL.g:1116:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Value' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'selected' (otherlv_5= 'at' )? ( (lv_name_6_0= ruleANDROID_ID ) ) )
            {
            // InternalAatDSL.g:1116:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Value' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'selected' (otherlv_5= 'at' )? ( (lv_name_6_0= ruleANDROID_ID ) ) )
            // InternalAatDSL.g:1117:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Value' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'selected' (otherlv_5= 'at' )? ( (lv_name_6_0= ruleANDROID_ID ) )
            {
            // InternalAatDSL.g:1117:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )?
            int alt23=2;
            int LA23_0 = input.LA(1);

            if ( ((LA23_0>=29 && LA23_0<=30)) ) {
                alt23=1;
            }
            switch (alt23) {
                case 1 :
                    // InternalAatDSL.g:1118:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    {
                    // InternalAatDSL.g:1118:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    // InternalAatDSL.g:1119:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    {
                    // InternalAatDSL.g:1119:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    int alt22=2;
                    int LA22_0 = input.LA(1);

                    if ( (LA22_0==29) ) {
                        alt22=1;
                    }
                    else if ( (LA22_0==30) ) {
                        alt22=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 22, 0, input);

                        throw nvae;
                    }
                    switch (alt22) {
                        case 1 :
                            // InternalAatDSL.g:1120:6: lv_op_0_1= 'And'
                            {
                            lv_op_0_1=(Token)match(input,29,FOLLOW_28); 

                            						newLeafNode(lv_op_0_1, grammarAccess.getValueIsSelectedAccess().getOpAndKeyword_0_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getValueIsSelectedRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_1, null);
                            					

                            }
                            break;
                        case 2 :
                            // InternalAatDSL.g:1131:6: lv_op_0_2= 'But'
                            {
                            lv_op_0_2=(Token)match(input,30,FOLLOW_28); 

                            						newLeafNode(lv_op_0_2, grammarAccess.getValueIsSelectedAccess().getOpButKeyword_0_0_1());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getValueIsSelectedRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_2, null);
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,36,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getValueIsSelectedAccess().getValueKeyword_1());
            		
            // InternalAatDSL.g:1148:3: ( (lv_value_2_0= ruleVALUE ) )
            // InternalAatDSL.g:1149:4: (lv_value_2_0= ruleVALUE )
            {
            // InternalAatDSL.g:1149:4: (lv_value_2_0= ruleVALUE )
            // InternalAatDSL.g:1150:5: lv_value_2_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getValueIsSelectedAccess().getValueVALUEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_29);
            lv_value_2_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getValueIsSelectedRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAatDSL.g:1167:3: (otherlv_3= 'is' )?
            int alt24=2;
            int LA24_0 = input.LA(1);

            if ( (LA24_0==31) ) {
                alt24=1;
            }
            switch (alt24) {
                case 1 :
                    // InternalAatDSL.g:1168:4: otherlv_3= 'is'
                    {
                    otherlv_3=(Token)match(input,31,FOLLOW_30); 

                    				newLeafNode(otherlv_3, grammarAccess.getValueIsSelectedAccess().getIsKeyword_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,37,FOLLOW_31); 

            			newLeafNode(otherlv_4, grammarAccess.getValueIsSelectedAccess().getSelectedKeyword_4());
            		
            // InternalAatDSL.g:1177:3: (otherlv_5= 'at' )?
            int alt25=2;
            int LA25_0 = input.LA(1);

            if ( (LA25_0==38) ) {
                alt25=1;
            }
            switch (alt25) {
                case 1 :
                    // InternalAatDSL.g:1178:4: otherlv_5= 'at'
                    {
                    otherlv_5=(Token)match(input,38,FOLLOW_11); 

                    				newLeafNode(otherlv_5, grammarAccess.getValueIsSelectedAccess().getAtKeyword_5());
                    			

                    }
                    break;

            }

            // InternalAatDSL.g:1183:3: ( (lv_name_6_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:1184:4: (lv_name_6_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:1184:4: (lv_name_6_0= ruleANDROID_ID )
            // InternalAatDSL.g:1185:5: lv_name_6_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getValueIsSelectedAccess().getNameANDROID_IDParserRuleCall_6_0());
            				
            pushFollow(FOLLOW_2);
            lv_name_6_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getValueIsSelectedRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_6_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleValueIsSelected"


    // $ANTLR start "entryRuleMessageIsDisplayed"
    // InternalAatDSL.g:1206:1: entryRuleMessageIsDisplayed returns [EObject current=null] : iv_ruleMessageIsDisplayed= ruleMessageIsDisplayed EOF ;
    public final EObject entryRuleMessageIsDisplayed() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleMessageIsDisplayed = null;


        try {
            // InternalAatDSL.g:1206:59: (iv_ruleMessageIsDisplayed= ruleMessageIsDisplayed EOF )
            // InternalAatDSL.g:1207:2: iv_ruleMessageIsDisplayed= ruleMessageIsDisplayed EOF
            {
             newCompositeNode(grammarAccess.getMessageIsDisplayedRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleMessageIsDisplayed=ruleMessageIsDisplayed();

            state._fsp--;

             current =iv_ruleMessageIsDisplayed; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleMessageIsDisplayed"


    // $ANTLR start "ruleMessageIsDisplayed"
    // InternalAatDSL.g:1213:1: ruleMessageIsDisplayed returns [EObject current=null] : ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Message' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'showed' ) ;
    public final EObject ruleMessageIsDisplayed() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_1=null;
        Token lv_op_0_2=null;
        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        AntlrDatatypeRuleToken lv_value_2_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:1219:2: ( ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Message' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'showed' ) )
            // InternalAatDSL.g:1220:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Message' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'showed' )
            {
            // InternalAatDSL.g:1220:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Message' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'showed' )
            // InternalAatDSL.g:1221:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Message' ( (lv_value_2_0= ruleVALUE ) ) (otherlv_3= 'is' )? otherlv_4= 'showed'
            {
            // InternalAatDSL.g:1221:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )?
            int alt27=2;
            int LA27_0 = input.LA(1);

            if ( ((LA27_0>=29 && LA27_0<=30)) ) {
                alt27=1;
            }
            switch (alt27) {
                case 1 :
                    // InternalAatDSL.g:1222:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    {
                    // InternalAatDSL.g:1222:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    // InternalAatDSL.g:1223:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    {
                    // InternalAatDSL.g:1223:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    int alt26=2;
                    int LA26_0 = input.LA(1);

                    if ( (LA26_0==29) ) {
                        alt26=1;
                    }
                    else if ( (LA26_0==30) ) {
                        alt26=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 26, 0, input);

                        throw nvae;
                    }
                    switch (alt26) {
                        case 1 :
                            // InternalAatDSL.g:1224:6: lv_op_0_1= 'And'
                            {
                            lv_op_0_1=(Token)match(input,29,FOLLOW_32); 

                            						newLeafNode(lv_op_0_1, grammarAccess.getMessageIsDisplayedAccess().getOpAndKeyword_0_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getMessageIsDisplayedRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_1, null);
                            					

                            }
                            break;
                        case 2 :
                            // InternalAatDSL.g:1235:6: lv_op_0_2= 'But'
                            {
                            lv_op_0_2=(Token)match(input,30,FOLLOW_32); 

                            						newLeafNode(lv_op_0_2, grammarAccess.getMessageIsDisplayedAccess().getOpButKeyword_0_0_1());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getMessageIsDisplayedRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_2, null);
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,39,FOLLOW_15); 

            			newLeafNode(otherlv_1, grammarAccess.getMessageIsDisplayedAccess().getMessageKeyword_1());
            		
            // InternalAatDSL.g:1252:3: ( (lv_value_2_0= ruleVALUE ) )
            // InternalAatDSL.g:1253:4: (lv_value_2_0= ruleVALUE )
            {
            // InternalAatDSL.g:1253:4: (lv_value_2_0= ruleVALUE )
            // InternalAatDSL.g:1254:5: lv_value_2_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getMessageIsDisplayedAccess().getValueVALUEParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_33);
            lv_value_2_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getMessageIsDisplayedRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_2_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAatDSL.g:1271:3: (otherlv_3= 'is' )?
            int alt28=2;
            int LA28_0 = input.LA(1);

            if ( (LA28_0==31) ) {
                alt28=1;
            }
            switch (alt28) {
                case 1 :
                    // InternalAatDSL.g:1272:4: otherlv_3= 'is'
                    {
                    otherlv_3=(Token)match(input,31,FOLLOW_34); 

                    				newLeafNode(otherlv_3, grammarAccess.getMessageIsDisplayedAccess().getIsKeyword_3());
                    			

                    }
                    break;

            }

            otherlv_4=(Token)match(input,40,FOLLOW_2); 

            			newLeafNode(otherlv_4, grammarAccess.getMessageIsDisplayedAccess().getShowedKeyword_4());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleMessageIsDisplayed"


    // $ANTLR start "entryRuleTextContains"
    // InternalAatDSL.g:1285:1: entryRuleTextContains returns [EObject current=null] : iv_ruleTextContains= ruleTextContains EOF ;
    public final EObject entryRuleTextContains() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTextContains = null;


        try {
            // InternalAatDSL.g:1285:53: (iv_ruleTextContains= ruleTextContains EOF )
            // InternalAatDSL.g:1286:2: iv_ruleTextContains= ruleTextContains EOF
            {
             newCompositeNode(grammarAccess.getTextContainsRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTextContains=ruleTextContains();

            state._fsp--;

             current =iv_ruleTextContains; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTextContains"


    // $ANTLR start "ruleTextContains"
    // InternalAatDSL.g:1292:1: ruleTextContains returns [EObject current=null] : ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Content' ( (lv_name_2_0= ruleANDROID_ID ) ) ( (lv_expression_3_0= ruleBooleanEvaluation ) ) ( (lv_value_4_0= ruleVALUE ) ) ) ;
    public final EObject ruleTextContains() throws RecognitionException {
        EObject current = null;

        Token lv_op_0_1=null;
        Token lv_op_0_2=null;
        Token otherlv_1=null;
        AntlrDatatypeRuleToken lv_name_2_0 = null;

        Enumerator lv_expression_3_0 = null;

        AntlrDatatypeRuleToken lv_value_4_0 = null;



        	enterRule();

        try {
            // InternalAatDSL.g:1298:2: ( ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Content' ( (lv_name_2_0= ruleANDROID_ID ) ) ( (lv_expression_3_0= ruleBooleanEvaluation ) ) ( (lv_value_4_0= ruleVALUE ) ) ) )
            // InternalAatDSL.g:1299:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Content' ( (lv_name_2_0= ruleANDROID_ID ) ) ( (lv_expression_3_0= ruleBooleanEvaluation ) ) ( (lv_value_4_0= ruleVALUE ) ) )
            {
            // InternalAatDSL.g:1299:2: ( ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Content' ( (lv_name_2_0= ruleANDROID_ID ) ) ( (lv_expression_3_0= ruleBooleanEvaluation ) ) ( (lv_value_4_0= ruleVALUE ) ) )
            // InternalAatDSL.g:1300:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )? otherlv_1= 'Content' ( (lv_name_2_0= ruleANDROID_ID ) ) ( (lv_expression_3_0= ruleBooleanEvaluation ) ) ( (lv_value_4_0= ruleVALUE ) )
            {
            // InternalAatDSL.g:1300:3: ( ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) ) )?
            int alt30=2;
            int LA30_0 = input.LA(1);

            if ( ((LA30_0>=29 && LA30_0<=30)) ) {
                alt30=1;
            }
            switch (alt30) {
                case 1 :
                    // InternalAatDSL.g:1301:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    {
                    // InternalAatDSL.g:1301:4: ( (lv_op_0_1= 'And' | lv_op_0_2= 'But' ) )
                    // InternalAatDSL.g:1302:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    {
                    // InternalAatDSL.g:1302:5: (lv_op_0_1= 'And' | lv_op_0_2= 'But' )
                    int alt29=2;
                    int LA29_0 = input.LA(1);

                    if ( (LA29_0==29) ) {
                        alt29=1;
                    }
                    else if ( (LA29_0==30) ) {
                        alt29=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 29, 0, input);

                        throw nvae;
                    }
                    switch (alt29) {
                        case 1 :
                            // InternalAatDSL.g:1303:6: lv_op_0_1= 'And'
                            {
                            lv_op_0_1=(Token)match(input,29,FOLLOW_35); 

                            						newLeafNode(lv_op_0_1, grammarAccess.getTextContainsAccess().getOpAndKeyword_0_0_0());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getTextContainsRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_1, null);
                            					

                            }
                            break;
                        case 2 :
                            // InternalAatDSL.g:1314:6: lv_op_0_2= 'But'
                            {
                            lv_op_0_2=(Token)match(input,30,FOLLOW_35); 

                            						newLeafNode(lv_op_0_2, grammarAccess.getTextContainsAccess().getOpButKeyword_0_0_1());
                            					

                            						if (current==null) {
                            							current = createModelElement(grammarAccess.getTextContainsRule());
                            						}
                            						setWithLastConsumed(current, "op", lv_op_0_2, null);
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;

            }

            otherlv_1=(Token)match(input,41,FOLLOW_11); 

            			newLeafNode(otherlv_1, grammarAccess.getTextContainsAccess().getContentKeyword_1());
            		
            // InternalAatDSL.g:1331:3: ( (lv_name_2_0= ruleANDROID_ID ) )
            // InternalAatDSL.g:1332:4: (lv_name_2_0= ruleANDROID_ID )
            {
            // InternalAatDSL.g:1332:4: (lv_name_2_0= ruleANDROID_ID )
            // InternalAatDSL.g:1333:5: lv_name_2_0= ruleANDROID_ID
            {

            					newCompositeNode(grammarAccess.getTextContainsAccess().getNameANDROID_IDParserRuleCall_2_0());
            				
            pushFollow(FOLLOW_36);
            lv_name_2_0=ruleANDROID_ID();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTextContainsRule());
            					}
            					set(
            						current,
            						"name",
            						lv_name_2_0,
            						"edu.uned.iss.tfm.AatDSL.ANDROID_ID");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAatDSL.g:1350:3: ( (lv_expression_3_0= ruleBooleanEvaluation ) )
            // InternalAatDSL.g:1351:4: (lv_expression_3_0= ruleBooleanEvaluation )
            {
            // InternalAatDSL.g:1351:4: (lv_expression_3_0= ruleBooleanEvaluation )
            // InternalAatDSL.g:1352:5: lv_expression_3_0= ruleBooleanEvaluation
            {

            					newCompositeNode(grammarAccess.getTextContainsAccess().getExpressionBooleanEvaluationEnumRuleCall_3_0());
            				
            pushFollow(FOLLOW_15);
            lv_expression_3_0=ruleBooleanEvaluation();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTextContainsRule());
            					}
            					set(
            						current,
            						"expression",
            						lv_expression_3_0,
            						"edu.uned.iss.tfm.AatDSL.BooleanEvaluation");
            					afterParserOrEnumRuleCall();
            				

            }


            }

            // InternalAatDSL.g:1369:3: ( (lv_value_4_0= ruleVALUE ) )
            // InternalAatDSL.g:1370:4: (lv_value_4_0= ruleVALUE )
            {
            // InternalAatDSL.g:1370:4: (lv_value_4_0= ruleVALUE )
            // InternalAatDSL.g:1371:5: lv_value_4_0= ruleVALUE
            {

            					newCompositeNode(grammarAccess.getTextContainsAccess().getValueVALUEParserRuleCall_4_0());
            				
            pushFollow(FOLLOW_2);
            lv_value_4_0=ruleVALUE();

            state._fsp--;


            					if (current==null) {
            						current = createModelElementForParent(grammarAccess.getTextContainsRule());
            					}
            					set(
            						current,
            						"value",
            						lv_value_4_0,
            						"edu.uned.iss.tfm.AatDSL.VALUE");
            					afterParserOrEnumRuleCall();
            				

            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTextContains"


    // $ANTLR start "entryRuleANDROID_ID"
    // InternalAatDSL.g:1392:1: entryRuleANDROID_ID returns [String current=null] : iv_ruleANDROID_ID= ruleANDROID_ID EOF ;
    public final String entryRuleANDROID_ID() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleANDROID_ID = null;


        try {
            // InternalAatDSL.g:1392:50: (iv_ruleANDROID_ID= ruleANDROID_ID EOF )
            // InternalAatDSL.g:1393:2: iv_ruleANDROID_ID= ruleANDROID_ID EOF
            {
             newCompositeNode(grammarAccess.getANDROID_IDRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleANDROID_ID=ruleANDROID_ID();

            state._fsp--;

             current =iv_ruleANDROID_ID.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleANDROID_ID"


    // $ANTLR start "ruleANDROID_ID"
    // InternalAatDSL.g:1399:1: ruleANDROID_ID returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (this_ID_0= RULE_ID ( (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID )* ) ;
    public final AntlrDatatypeRuleToken ruleANDROID_ID() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token this_ID_0=null;
        Token kw=null;
        Token this_ID_8=null;


        	enterRule();

        try {
            // InternalAatDSL.g:1405:2: ( (this_ID_0= RULE_ID ( (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID )* ) )
            // InternalAatDSL.g:1406:2: (this_ID_0= RULE_ID ( (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID )* )
            {
            // InternalAatDSL.g:1406:2: (this_ID_0= RULE_ID ( (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID )* )
            // InternalAatDSL.g:1407:3: this_ID_0= RULE_ID ( (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID )*
            {
            this_ID_0=(Token)match(input,RULE_ID,FOLLOW_37); 

            			current.merge(this_ID_0);
            		

            			newLeafNode(this_ID_0, grammarAccess.getANDROID_IDAccess().getIDTerminalRuleCall_0());
            		
            // InternalAatDSL.g:1414:3: ( (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID )*
            loop32:
            do {
                int alt32=2;
                int LA32_0 = input.LA(1);

                if ( ((LA32_0>=42 && LA32_0<=48)) ) {
                    alt32=1;
                }


                switch (alt32) {
            	case 1 :
            	    // InternalAatDSL.g:1415:4: (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' ) this_ID_8= RULE_ID
            	    {
            	    // InternalAatDSL.g:1415:4: (kw= '.' | kw= '\\u00E1' | kw= '\\u00E9' | kw= '\\u00ED' | kw= '\\u00F3' | kw= '\\u00FA' | kw= '\\u00F1' )
            	    int alt31=7;
            	    switch ( input.LA(1) ) {
            	    case 42:
            	        {
            	        alt31=1;
            	        }
            	        break;
            	    case 43:
            	        {
            	        alt31=2;
            	        }
            	        break;
            	    case 44:
            	        {
            	        alt31=3;
            	        }
            	        break;
            	    case 45:
            	        {
            	        alt31=4;
            	        }
            	        break;
            	    case 46:
            	        {
            	        alt31=5;
            	        }
            	        break;
            	    case 47:
            	        {
            	        alt31=6;
            	        }
            	        break;
            	    case 48:
            	        {
            	        alt31=7;
            	        }
            	        break;
            	    default:
            	        NoViableAltException nvae =
            	            new NoViableAltException("", 31, 0, input);

            	        throw nvae;
            	    }

            	    switch (alt31) {
            	        case 1 :
            	            // InternalAatDSL.g:1416:5: kw= '.'
            	            {
            	            kw=(Token)match(input,42,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getFullStopKeyword_1_0_0());
            	            				

            	            }
            	            break;
            	        case 2 :
            	            // InternalAatDSL.g:1422:5: kw= '\\u00E1'
            	            {
            	            kw=(Token)match(input,43,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getLatinSmallLetterAWithAcuteKeyword_1_0_1());
            	            				

            	            }
            	            break;
            	        case 3 :
            	            // InternalAatDSL.g:1428:5: kw= '\\u00E9'
            	            {
            	            kw=(Token)match(input,44,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getLatinSmallLetterEWithAcuteKeyword_1_0_2());
            	            				

            	            }
            	            break;
            	        case 4 :
            	            // InternalAatDSL.g:1434:5: kw= '\\u00ED'
            	            {
            	            kw=(Token)match(input,45,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getLatinSmallLetterIWithAcuteKeyword_1_0_3());
            	            				

            	            }
            	            break;
            	        case 5 :
            	            // InternalAatDSL.g:1440:5: kw= '\\u00F3'
            	            {
            	            kw=(Token)match(input,46,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getLatinSmallLetterOWithAcuteKeyword_1_0_4());
            	            				

            	            }
            	            break;
            	        case 6 :
            	            // InternalAatDSL.g:1446:5: kw= '\\u00FA'
            	            {
            	            kw=(Token)match(input,47,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getLatinSmallLetterUWithAcuteKeyword_1_0_5());
            	            				

            	            }
            	            break;
            	        case 7 :
            	            // InternalAatDSL.g:1452:5: kw= '\\u00F1'
            	            {
            	            kw=(Token)match(input,48,FOLLOW_38); 

            	            					current.merge(kw);
            	            					newLeafNode(kw, grammarAccess.getANDROID_IDAccess().getLatinSmallLetterNWithTildeKeyword_1_0_6());
            	            				

            	            }
            	            break;

            	    }

            	    this_ID_8=(Token)match(input,RULE_ID,FOLLOW_37); 

            	    				current.merge(this_ID_8);
            	    			

            	    				newLeafNode(this_ID_8, grammarAccess.getANDROID_IDAccess().getIDTerminalRuleCall_1_1());
            	    			

            	    }
            	    break;

            	default :
            	    break loop32;
                }
            } while (true);


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleANDROID_ID"


    // $ANTLR start "entryRuleVALUE"
    // InternalAatDSL.g:1470:1: entryRuleVALUE returns [String current=null] : iv_ruleVALUE= ruleVALUE EOF ;
    public final String entryRuleVALUE() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleVALUE = null;


        try {
            // InternalAatDSL.g:1470:45: (iv_ruleVALUE= ruleVALUE EOF )
            // InternalAatDSL.g:1471:2: iv_ruleVALUE= ruleVALUE EOF
            {
             newCompositeNode(grammarAccess.getVALUERule()); 
            pushFollow(FOLLOW_1);
            iv_ruleVALUE=ruleVALUE();

            state._fsp--;

             current =iv_ruleVALUE.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleVALUE"


    // $ANTLR start "ruleVALUE"
    // InternalAatDSL.g:1477:1: ruleVALUE returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : (kw= '\\\\' this_STRING_1= RULE_STRING ) ;
    public final AntlrDatatypeRuleToken ruleVALUE() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;
        Token this_STRING_1=null;


        	enterRule();

        try {
            // InternalAatDSL.g:1483:2: ( (kw= '\\\\' this_STRING_1= RULE_STRING ) )
            // InternalAatDSL.g:1484:2: (kw= '\\\\' this_STRING_1= RULE_STRING )
            {
            // InternalAatDSL.g:1484:2: (kw= '\\\\' this_STRING_1= RULE_STRING )
            // InternalAatDSL.g:1485:3: kw= '\\\\' this_STRING_1= RULE_STRING
            {
            kw=(Token)match(input,49,FOLLOW_3); 

            			current.merge(kw);
            			newLeafNode(kw, grammarAccess.getVALUEAccess().getBackslashKeyword_0());
            		
            this_STRING_1=(Token)match(input,RULE_STRING,FOLLOW_2); 

            			current.merge(this_STRING_1);
            		

            			newLeafNode(this_STRING_1, grammarAccess.getVALUEAccess().getSTRINGTerminalRuleCall_1());
            		

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleVALUE"


    // $ANTLR start "ruleBooleanEvaluation"
    // InternalAatDSL.g:1501:1: ruleBooleanEvaluation returns [Enumerator current=null] : ( (enumLiteral_0= 'startsWith' ) | (enumLiteral_1= 'endsWith' ) | (enumLiteral_2= 'contains' ) | (enumLiteral_3= 'equals' ) | (enumLiteral_4= 'greaterThan' ) | (enumLiteral_5= 'greaterEqualsThan' ) | (enumLiteral_6= 'lessThan' ) | (enumLiteral_7= 'lessEqualsThan' ) ) ;
    public final Enumerator ruleBooleanEvaluation() throws RecognitionException {
        Enumerator current = null;

        Token enumLiteral_0=null;
        Token enumLiteral_1=null;
        Token enumLiteral_2=null;
        Token enumLiteral_3=null;
        Token enumLiteral_4=null;
        Token enumLiteral_5=null;
        Token enumLiteral_6=null;
        Token enumLiteral_7=null;


        	enterRule();

        try {
            // InternalAatDSL.g:1507:2: ( ( (enumLiteral_0= 'startsWith' ) | (enumLiteral_1= 'endsWith' ) | (enumLiteral_2= 'contains' ) | (enumLiteral_3= 'equals' ) | (enumLiteral_4= 'greaterThan' ) | (enumLiteral_5= 'greaterEqualsThan' ) | (enumLiteral_6= 'lessThan' ) | (enumLiteral_7= 'lessEqualsThan' ) ) )
            // InternalAatDSL.g:1508:2: ( (enumLiteral_0= 'startsWith' ) | (enumLiteral_1= 'endsWith' ) | (enumLiteral_2= 'contains' ) | (enumLiteral_3= 'equals' ) | (enumLiteral_4= 'greaterThan' ) | (enumLiteral_5= 'greaterEqualsThan' ) | (enumLiteral_6= 'lessThan' ) | (enumLiteral_7= 'lessEqualsThan' ) )
            {
            // InternalAatDSL.g:1508:2: ( (enumLiteral_0= 'startsWith' ) | (enumLiteral_1= 'endsWith' ) | (enumLiteral_2= 'contains' ) | (enumLiteral_3= 'equals' ) | (enumLiteral_4= 'greaterThan' ) | (enumLiteral_5= 'greaterEqualsThan' ) | (enumLiteral_6= 'lessThan' ) | (enumLiteral_7= 'lessEqualsThan' ) )
            int alt33=8;
            switch ( input.LA(1) ) {
            case 50:
                {
                alt33=1;
                }
                break;
            case 51:
                {
                alt33=2;
                }
                break;
            case 52:
                {
                alt33=3;
                }
                break;
            case 53:
                {
                alt33=4;
                }
                break;
            case 54:
                {
                alt33=5;
                }
                break;
            case 55:
                {
                alt33=6;
                }
                break;
            case 56:
                {
                alt33=7;
                }
                break;
            case 57:
                {
                alt33=8;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 33, 0, input);

                throw nvae;
            }

            switch (alt33) {
                case 1 :
                    // InternalAatDSL.g:1509:3: (enumLiteral_0= 'startsWith' )
                    {
                    // InternalAatDSL.g:1509:3: (enumLiteral_0= 'startsWith' )
                    // InternalAatDSL.g:1510:4: enumLiteral_0= 'startsWith'
                    {
                    enumLiteral_0=(Token)match(input,50,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getStartsWithEnumLiteralDeclaration_0().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_0, grammarAccess.getBooleanEvaluationAccess().getStartsWithEnumLiteralDeclaration_0());
                    			

                    }


                    }
                    break;
                case 2 :
                    // InternalAatDSL.g:1517:3: (enumLiteral_1= 'endsWith' )
                    {
                    // InternalAatDSL.g:1517:3: (enumLiteral_1= 'endsWith' )
                    // InternalAatDSL.g:1518:4: enumLiteral_1= 'endsWith'
                    {
                    enumLiteral_1=(Token)match(input,51,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getEndsWithEnumLiteralDeclaration_1().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_1, grammarAccess.getBooleanEvaluationAccess().getEndsWithEnumLiteralDeclaration_1());
                    			

                    }


                    }
                    break;
                case 3 :
                    // InternalAatDSL.g:1525:3: (enumLiteral_2= 'contains' )
                    {
                    // InternalAatDSL.g:1525:3: (enumLiteral_2= 'contains' )
                    // InternalAatDSL.g:1526:4: enumLiteral_2= 'contains'
                    {
                    enumLiteral_2=(Token)match(input,52,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getContainsEnumLiteralDeclaration_2().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_2, grammarAccess.getBooleanEvaluationAccess().getContainsEnumLiteralDeclaration_2());
                    			

                    }


                    }
                    break;
                case 4 :
                    // InternalAatDSL.g:1533:3: (enumLiteral_3= 'equals' )
                    {
                    // InternalAatDSL.g:1533:3: (enumLiteral_3= 'equals' )
                    // InternalAatDSL.g:1534:4: enumLiteral_3= 'equals'
                    {
                    enumLiteral_3=(Token)match(input,53,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getEqualsEnumLiteralDeclaration_3().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_3, grammarAccess.getBooleanEvaluationAccess().getEqualsEnumLiteralDeclaration_3());
                    			

                    }


                    }
                    break;
                case 5 :
                    // InternalAatDSL.g:1541:3: (enumLiteral_4= 'greaterThan' )
                    {
                    // InternalAatDSL.g:1541:3: (enumLiteral_4= 'greaterThan' )
                    // InternalAatDSL.g:1542:4: enumLiteral_4= 'greaterThan'
                    {
                    enumLiteral_4=(Token)match(input,54,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getGreaterThanEnumLiteralDeclaration_4().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_4, grammarAccess.getBooleanEvaluationAccess().getGreaterThanEnumLiteralDeclaration_4());
                    			

                    }


                    }
                    break;
                case 6 :
                    // InternalAatDSL.g:1549:3: (enumLiteral_5= 'greaterEqualsThan' )
                    {
                    // InternalAatDSL.g:1549:3: (enumLiteral_5= 'greaterEqualsThan' )
                    // InternalAatDSL.g:1550:4: enumLiteral_5= 'greaterEqualsThan'
                    {
                    enumLiteral_5=(Token)match(input,55,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getGreaterEqualsThanEnumLiteralDeclaration_5().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_5, grammarAccess.getBooleanEvaluationAccess().getGreaterEqualsThanEnumLiteralDeclaration_5());
                    			

                    }


                    }
                    break;
                case 7 :
                    // InternalAatDSL.g:1557:3: (enumLiteral_6= 'lessThan' )
                    {
                    // InternalAatDSL.g:1557:3: (enumLiteral_6= 'lessThan' )
                    // InternalAatDSL.g:1558:4: enumLiteral_6= 'lessThan'
                    {
                    enumLiteral_6=(Token)match(input,56,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getLessThanEnumLiteralDeclaration_6().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_6, grammarAccess.getBooleanEvaluationAccess().getLessThanEnumLiteralDeclaration_6());
                    			

                    }


                    }
                    break;
                case 8 :
                    // InternalAatDSL.g:1565:3: (enumLiteral_7= 'lessEqualsThan' )
                    {
                    // InternalAatDSL.g:1565:3: (enumLiteral_7= 'lessEqualsThan' )
                    // InternalAatDSL.g:1566:4: enumLiteral_7= 'lessEqualsThan'
                    {
                    enumLiteral_7=(Token)match(input,57,FOLLOW_2); 

                    				current = grammarAccess.getBooleanEvaluationAccess().getLessEqualsThanEnumLiteralDeclaration_7().getEnumLiteral().getInstance();
                    				newLeafNode(enumLiteral_7, grammarAccess.getBooleanEvaluationAccess().getLessEqualsThanEnumLiteralDeclaration_7());
                    			

                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleBooleanEvaluation"

    // Delegated rules


    protected DFA14 dfa14 = new DFA14(this);
    static final String dfa_1s = "\24\uffff";
    static final String dfa_2s = "\1\6\2\7\1\37\5\uffff\7\7\1\40\1\37\2\uffff";
    static final String dfa_3s = "\3\51\1\60\5\uffff\7\7\1\41\1\60\2\uffff";
    static final String dfa_4s = "\4\uffff\1\3\1\4\1\5\1\6\1\7\11\uffff\1\2\1\1";
    static final String dfa_5s = "\24\uffff}>";
    static final String[] dfa_6s = {
            "\1\10\1\3\25\uffff\1\1\1\2\3\uffff\1\4\1\uffff\1\5\2\uffff\1\6\1\uffff\1\7",
            "\1\3\32\uffff\1\4\1\uffff\1\5\2\uffff\1\6\1\uffff\1\7",
            "\1\3\32\uffff\1\4\1\uffff\1\5\2\uffff\1\6\1\uffff\1\7",
            "\1\20\12\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17",
            "",
            "",
            "",
            "",
            "",
            "\1\21",
            "\1\21",
            "\1\21",
            "\1\21",
            "\1\21",
            "\1\21",
            "\1\21",
            "\1\23\1\22",
            "\1\20\12\uffff\1\11\1\12\1\13\1\14\1\15\1\16\1\17",
            "",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA14 extends DFA {

        public DFA14(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 14;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "805:2: (this_IsEnabled_0= ruleIsEnabled | this_IsVisible_1= ruleIsVisible | this_OptionIsChecked_2= ruleOptionIsChecked | this_ValueIsSelected_3= ruleValueIsSelected | this_MessageIsDisplayed_4= ruleMessageIsDisplayed | this_TextContains_5= ruleTextContains | ( () this_COMMENT_7= RULE_COMMENT ) )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002002L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000020L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x000000000000C000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x00000294600200C0L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000000008000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x000000000DDC0040L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000060000080L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x00000294600200C2L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x000000000DDC0042L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000000180000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0002000000000000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000200000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000001C00000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000002000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000004000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000080000000L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_25 = new BitSet(new long[]{0x0000000400000000L});
    public static final BitSet FOLLOW_26 = new BitSet(new long[]{0x0000000880000000L});
    public static final BitSet FOLLOW_27 = new BitSet(new long[]{0x0000000800000000L});
    public static final BitSet FOLLOW_28 = new BitSet(new long[]{0x0000001000000000L});
    public static final BitSet FOLLOW_29 = new BitSet(new long[]{0x0000002080000000L});
    public static final BitSet FOLLOW_30 = new BitSet(new long[]{0x0000002000000000L});
    public static final BitSet FOLLOW_31 = new BitSet(new long[]{0x0000004060000080L});
    public static final BitSet FOLLOW_32 = new BitSet(new long[]{0x0000008000000000L});
    public static final BitSet FOLLOW_33 = new BitSet(new long[]{0x0000010080000000L});
    public static final BitSet FOLLOW_34 = new BitSet(new long[]{0x0000010000000000L});
    public static final BitSet FOLLOW_35 = new BitSet(new long[]{0x0000020000000000L});
    public static final BitSet FOLLOW_36 = new BitSet(new long[]{0x03FC000000000000L});
    public static final BitSet FOLLOW_37 = new BitSet(new long[]{0x0001FC0000000002L});
    public static final BitSet FOLLOW_38 = new BitSet(new long[]{0x0000000000000080L});

}